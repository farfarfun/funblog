# coding:utf-8

'''
@author = super_fazai
@File    : shell_utils.py
@connect : superonesfazai@gmail.com
'''

"""
shell utils
"""

from click import command as click_command
from click import option as click_option
from click import echo as click_echo

