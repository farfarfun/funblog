# coding:utf-8

'''
@author = super_fazai
@File    : config.py
@Time    : 2016/8/13 17:25
@connect : superonesfazai@gmail.com
'''

config = {
    "template_file": "base_spider_template.py",
    "author": "super_fazai",
    "create_time": "",
    "file_name": "base_spider_demo",
    "class_name": "FZBaseSpider",
    "connect": "superonesfazai@gmail.com",
}